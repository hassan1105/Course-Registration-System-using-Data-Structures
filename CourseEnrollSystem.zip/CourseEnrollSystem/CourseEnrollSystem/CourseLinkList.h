#ifndef COURSELINKLIST_H
#define COURSELINKLIST_H

#include "Course.h"

class CourseLinkList
{
private:
	Course *FirstCourse, *LastCourse;
	int noOfCourses;

public:

	CourseLinkList();

	Course* CreateCourse();
	void NewCourse(CourseDetail model);
	void AddCourse(CourseDetail model);
	void UpdateCourse(CourseDetail model);
	CourseDetail DeleteCourse(CourseDetail model);
	CourseDetail DeleteLastCourse(CourseDetail model);
	CourseDetail DeleteFirstCourse(CourseDetail model);
	bool IsCourseListEmpty();
	int getNoOfCourses();
	CourseDetail SearchCourse(string coursecode);
	void setFirstCourse(Course *node);
	Course* getFirstCourse();
	Course* getSpecificCourse(string courseCode);
};

void CourseLinkList::setFirstCourse(Course *node)
{
	FirstCourse = node;
}

Course* CourseLinkList::getFirstCourse()
{
	return FirstCourse;
}

int CourseLinkList::getNoOfCourses()
{
	return noOfCourses;
}


// constructor of the class courseLinkList
CourseLinkList::CourseLinkList()
{
	FirstCourse = NULL;
	LastCourse = NULL;
	noOfCourses = 0;
}

// this function make a node and return pointer 
Course* CourseLinkList::CreateCourse()
{
	Course *p;
	p = new Course();
	return p;
}


// function for feeding data from user and save in a node 
void CourseLinkList::NewCourse(CourseDetail model)
{
	Course *q = CreateCourse();
	q->setCourseCode(model._mCourseCode);
	q->setCourseName(model._mName);
	q->setCreditHrs(model._mCreditHr);
	q->setPreReq(model._preReq);
	q->setStatus(model._mStatus);
	q->setCourseNode(NULL);

	FirstCourse = q;
	LastCourse = q;

	noOfCourses = noOfCourses++;
}


//function "if the linklist is empty call Newcourse() else make a pointer and assigned data & set next to null
void CourseLinkList::AddCourse(CourseDetail model)
{
	if (FirstCourse == NULL)
		NewCourse(model);
	else
	{
		Course *q = NULL, *p;

		for (p = FirstCourse; p->getCourseNode() != NULL; p = p->getCourseNode())
		{

		}
		q = CreateCourse();
		q->setCourseCode(model._mCourseCode);
		q->setCourseName(model._mName);
		q->setCreditHrs(model._mCreditHr);
		q->setPreReq(model._preReq);
		q->setStatus(model._mStatus);

		q->setCourseNode(NULL);

		p->setCourseNode(q);
		LastCourse = q;

		noOfCourses = noOfCourses + 1;
	}
}


// passing course code as an argument and return the course pointer
Course* CourseLinkList::getSpecificCourse(string courseCode)
{
	bool isfound = false;

	if (FirstCourse != NULL)
	{
		Course *p;

		for (p = FirstCourse; p!= NULL; p = p->getCourseNode())
		{
			if (p->getCourseCode() == courseCode)
			{
				isfound = true;
				break;
			}
		}

		if (isfound)
		{
			return p;
		}
		else
			return NULL;
	}
	return NULL;
}



// function for updating course detail 
void CourseLinkList::UpdateCourse(CourseDetail model)
{
	if (FirstCourse != NULL)
	{
		Course *p;

		for (p = FirstCourse; p->getCourseNode() != NULL && p->getCourseCode() != model._mCourseCode; p = p->getCourseNode())
		{

		}

		p->setCourseName(model._mName);
		p->setCreditHrs(model._mCreditHr);
		p->setPreReq(model._preReq);
	}
}

//check is the linklist empty r not
bool CourseLinkList::IsCourseListEmpty()
{
	return FirstCourse == NULL;
}


//delete first course
CourseDetail CourseLinkList::DeleteFirstCourse(CourseDetail model)
{
	if (FirstCourse == NULL)
		cout << "Underflow";
	else
	{
		Course *p = FirstCourse;
		FirstCourse = FirstCourse->getCourseNode();
		LastCourse = FirstCourse->getCourseNode();
		noOfCourses = 0;

		CourseDetail temp;
		temp._mCourseCode = p->getCourseCode();
		temp._mCreditHr = p->getCreditHrs();
		temp._mName = p->getCourseName();
		temp._preReq = p->getPreReq();

		delete p;

		return temp;
	}
}


//delete last course node
CourseDetail CourseLinkList::DeleteLastCourse(CourseDetail model)
{
	if (FirstCourse == NULL)
		cout << "Underflow";
	if (FirstCourse->getCourseNode() == NULL)
		return (DeleteFirstCourse(model));
	else
	{
		Course *q = NULL, *p;
		for (p = FirstCourse; p->getCourseNode() != NULL; p = p->getCourseNode())
			q = p; //P points to the last node and q points to the 2nd last

		q->setCourseNode(NULL);

		LastCourse = q;

		CourseDetail temp;
		temp._mCourseCode = p->getCourseCode();
		temp._mCreditHr = p->getCreditHrs();
		temp._mName = p->getCourseName();
		temp._preReq = p->getPreReq();

		delete p;

		noOfCourses = noOfCourses--;

		return temp;
	}
}


//delete course node by course node
CourseDetail CourseLinkList::DeleteCourse(CourseDetail model)
{
	if (FirstCourse == NULL)
		cout << "Underflow";
	if (FirstCourse->getCourseNode() == NULL)
		return (DeleteFirstCourse(model));
	else
	{
		Course *q = NULL, *p;//i change p to p->getcoursenode()
		for (p = FirstCourse; p->getCourseNode() != NULL && p->getCourseCode() != model._mCourseCode; p = p->getCourseNode())
			q = p; //P points to the last node and q points to the 2nd last

		if (p == NULL)
			cout << "Not found";
		else if (p->getCourseNode() == NULL)
			return DeleteLastCourse(model);
		else
		{
			Course  *r = p->getCourseNode();
			q->setCourseNode(p->getCourseNode());

			CourseDetail temp;
			temp._mCourseCode = p->getCourseCode();
			temp._mCreditHr = p->getCreditHrs();
			temp._mName = p->getCourseName();
			temp._preReq = p->getPreReq();

			delete p;

			noOfCourses = noOfCourses--;

			return temp;
		}
	}
}


//searches for a course and return course detail
CourseDetail CourseLinkList::SearchCourse(string coursecode)
{
	if (FirstCourse == NULL)
		cout << "Underflow";
	else
	{
		Course *p;
		for (p = FirstCourse; p != NULL && p->getCourseCode() != coursecode; p = p->getCourseNode());

		CourseDetail temp;
		temp._mCourseCode = p->getCourseCode();
		temp._mCreditHr = p->getCreditHrs();
		temp._mName = p->getCourseName();

		return temp;
	}
}


#endif