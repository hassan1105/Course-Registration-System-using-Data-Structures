#ifndef COURSE_H
#define COURSE_H

#include "CourseDetail.h"

class Course
{
private:

	CourseDetail _courseDetail;
	Course *courseNode;

public:

	Course();
	Course(CourseDetail _argCourseDetail, Course *node);
	
	void setCourseCode(string _argCourseCode);
	void setCourseName(string _argCourseName);
	void setCreditHrs(int _argCourseHrs);
	void setCourseNode(Course *node);
	void setPreReq(string _preReq);
	void setStatus(string status);
	
	string getStatus();
	CourseDetail getCourseDetail();
	string getCourseCode();
	string getCourseName();
	int getCreditHrs();
	Course* getCourseNode();
	string getPreReq();

};

void Course::setStatus(string status)
{
	_courseDetail._mStatus = status;
}

string Course::getStatus()
{
	return _courseDetail._mStatus;
}

CourseDetail Course::getCourseDetail()
{
	return _courseDetail;
}

//Constructor 
Course::Course()
{
	_courseDetail._mCourseCode = "";
	_courseDetail._mName = "";
	_courseDetail._mCreditHr = -1;

	courseNode = NULL;
}

Course::Course(CourseDetail _argCourseDetail, Course *node)
{
	_courseDetail._mCourseCode = _argCourseDetail._mCourseCode;
	_courseDetail._mName = _argCourseDetail._mName;
	_courseDetail._mCreditHr = _argCourseDetail._mCreditHr;

	courseNode = node;
}

void Course::setCourseCode(string _argCourseCode)
{
	_courseDetail._mCourseCode = _argCourseCode;
}

void Course::setCourseName(string _argCourseName)
{
	_courseDetail._mName = _argCourseName;
}

void Course::setCreditHrs(int _argCourseHrs)
{
	_courseDetail._mCreditHr = _argCourseHrs;
}

void Course::setCourseNode(Course *node)
{
	courseNode = node;
}

void Course::setPreReq(string _preReq)
{
	_courseDetail._preReq = _preReq;
}

string Course::getCourseCode()
{
	return _courseDetail._mCourseCode;
}

string Course::getCourseName()
{
	return _courseDetail._mName;
}

int Course::getCreditHrs()
{
	return _courseDetail._mCreditHr;
}

Course* Course::getCourseNode()
{
	return courseNode;
}

string Course::getPreReq()
{
	return _courseDetail._preReq;
}

#endif