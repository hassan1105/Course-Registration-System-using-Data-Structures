#ifndef USER_H
#define USER_H

#include "CourseLinkList.h"
#include "UserDetail.h"

class User
{
private:
	UserDetail _UserDetail;
	CourseLinkList Cnode;
	User *Snode;

public:

	User();
	User(UserDetail _argUserDetail, User *snode);
	
	void setName(string _argName);
	void setRegNum(int _argRegNum);
	void setEmail(string _argEmail);
	void setDOB(string dob);
	void setPassword(string _argpass);
	void setCNIC(string _argcnic);
	void setStatus(string status);
	void setUserNode(User *snode);
	void setType(string type);
	
	string getType();
	string getName();
	int getRegNum();
	string getEmail();
	string getDOB();
	string getPassword();
	string getCNIC();
	string getStatus();
	User* getUserNode();

	void AddCourse(Course *course);

	CourseLinkList getCourseLinkList();
	
	UserDetail getUserDetail();
	
	void setCourseLinkList(CourseLinkList ccnode);
};

void User::setCourseLinkList(CourseLinkList ccnode)
{
	Cnode = ccnode;
}

UserDetail User::getUserDetail()
{
	return _UserDetail;
}

CourseLinkList User::getCourseLinkList()
{
	return Cnode;
}

void User::AddCourse(Course *course)
{
	Cnode.AddCourse(course->getCourseDetail());
}

User::User()
{
	_UserDetail._mRegNumber = -1;
	_UserDetail._mCNIC = "";
	_UserDetail._mDOB = "";
	_UserDetail._mEmail = "";
	_UserDetail._mName = "";
	_UserDetail._mPassword = "";
	_UserDetail._mStatus = "";

	Cnode.setFirstCourse(NULL);
	Snode = NULL;
}

User::User(UserDetail _argUserDetail, User *snode)
{

	_UserDetail._mRegNumber = _argUserDetail._mRegNumber;
	_UserDetail._mCNIC = _argUserDetail._mCNIC;
	_UserDetail._mDOB = _argUserDetail._mDOB;
	_UserDetail._mEmail = _argUserDetail._mEmail;
	_UserDetail._mName = _argUserDetail._mName;
	_UserDetail._mPassword = _argUserDetail._mPassword;
	_UserDetail._mStatus = _argUserDetail._mStatus;

	Cnode.setFirstCourse(NULL);
	Snode = snode;

}

void User::setName(string _argName)
{
	_UserDetail._mName = _argName;
}

void User::setRegNum(int _argRegNum)
{
	_UserDetail._mRegNumber = _argRegNum;
}

void User::setEmail(string _argEmail)
{
	_UserDetail._mEmail = _argEmail;
}

void User::setDOB(string dob)
{
	_UserDetail._mDOB = dob;
}

void User::setPassword(string _argpass)
{
	_UserDetail._mPassword = _argpass;
}

void User::setCNIC(string _argcnic)
{
	_UserDetail._mCNIC = _argcnic;
}

void User::setStatus(string status)
{
	_UserDetail._mStatus = status;
}

void User::setUserNode(User *snode)
{
	Snode = snode;
}

string User::getName()
{
	return _UserDetail._mName;
}

int User::getRegNum()
{
	return _UserDetail._mRegNumber;
}
string User::getEmail()
{
	return _UserDetail._mEmail;
}
string User::getDOB()
{
	return _UserDetail._mDOB;
}
string User::getPassword()
{
	return _UserDetail._mPassword;
}
string User::getCNIC()
{
	return _UserDetail._mCNIC;
}
string User::getStatus()
{
	return _UserDetail._mStatus;
}

User* User::getUserNode()
{
	return Snode;
}

void User::setType(string type)
{
	_UserDetail._mType = type;
}

string User::getType()
{
	return _UserDetail._mType;
}

#endif