#ifndef MYINTERFACE_H
#define MYINTERFACE_H

#include <iostream> 
#include <time.h> 
#include <cstring>
#include <string> 
#include <fstream>
#include <iomanip>
#include <conio.h>
#include <cstdlib>
#include <windows.h>

#include "UserLinkList.h"
#include "CourseLinkList.h"

using namespace std;

class myInterface
{
public:

	CourseLinkList courseLinkList;
	UserLinkList allUserLinkList;
	UserLinkList teacherLinkList;
	UserLinkList studentLinkList;
	UserLinkList enrolledStudentList;
	UserLinkList assignedTeacherList;

	int isvalidLoopInput(int value)
	{
		string temp; int _temp;
		if (value == 3)
		{
			while (cin >> temp)
			{
				if (temp == "1" || temp == "2" || temp == "3")
					break;
				else
					cout << "\t\t\t\t\tInvalid Input please re Enter >>";
			}
		}
		else if (value==4)
		{
			while (cin >> temp)
			{
				if (temp == "1" || temp == "2" || temp == "3" || temp=="4")
					break;
				else
					cout << "\t\t\t\t\tInvalid Input please re Enter >>";
			}
		}
		else if (value == 7)
		{
			while (cin >> temp)
			{
				if (temp == "1" || temp == "2" || temp == "3" || temp == "4" || temp == "5" || temp == "6" || temp == "7")
					break;
				else
					cout << "\t\t\t\t\tInvalid Input please re Enter >>";
			}
		}
		_temp = stoi(temp);
		return _temp;
	}
	void displayGoodByeMessage()
	{
		cout << "\n\t\t\t\t**********************************************************"
			<< "\n\t\t\t\t*** Thanks for using Student Course Enrollment Program ***"
			<< "\n\t\t\t\t**********************************************************\n";
	}
	
	void wellcomeScreen()
	{
		cout << "\n\t\t\t\t*********************************************************";
		cout << "\n\t\t\t\t*** Wellcome to the Student Course Enrollment Program ***";
		cout << "\n\t\t\t\t*********************************************************" << endl << endl;
	}

	void clearScreen()
	{
		system("cls");
	}

	int loginMenuScreen()
	{
		//variable to hold the user entered choice
		int choice;

		//do while loop to keep on receiving user choice
		//until valid choice is entered
		do
		{
			//Calling clearScreen()
			clearScreen();

			//Calling wellcomeScreen() function
			wellcomeScreen();

			//display the login screen menu
			cout << "\n\t\t\t\t\tSelect from following options:\n";
			cout << "\t\t\t\t\t1.\tLogin" << endl
				<< "\t\t\t\t\t2.\tCreate New Account" << endl
				<< "\t\t\t\t\t3.\tExit" << endl;

			//prompt for the user choice
			cout << "\t\t\t\t\tEnter your choice (1,2,3):\t";
			//input value from user

			choice = isvalidLoopInput(3);

		} while (!(choice == 1 || choice == 2 || choice == 3));

		//return user choice
		return choice;
	}

	// Generates 3 digit random number
	// numbers in range [lower, upper]. 
	int genVerificationCode()
	{
		//declaring lower and upper limit 
		int lower = 100;
		int upper = 999;


		//number variable will hold the generated random number
		int num = (rand() % (upper - lower + 1)) + lower;

		//returning the generated random number
		return num;
	}

	//receive the verification code
	//save verification code to the file named Email.txt
	void sendCodeByEmail(int verificationCode)
	{
		//ofstream class object to hold email.txt file
		ofstream emailFile("Email.txt");

		//check if file opened successfully
		if (emailFile.is_open())
		{
			//saving verification code to the file name Email.txt
			emailFile << verificationCode << endl;

			//closing file
			emailFile.close();

			//display message
			cout << "\n\tVerification code has been sended to your Email\n\t";
			system("pause");
		}
		//else display error message
		else
			cout << "\n\tUnable to open file";
	}

	//function that will prompt for the basic user information
	//save it to the file named Users
	//generate 3 digit verification code
	//save the verification code to the file named Email
	void createAccount()
	{
		UserLinkList userLinkList;

		int num_dob = 0;

		string usr_type;
		int verification_code;
		char confirmation;
		bool ageValid = false;

		//Calling clearScreen()
		clearScreen();

		//Read all user details from file to Link list
		//ifstream class object
		ifstream userfileread("Users.txt");

		//check if file opens
		if (userfileread.is_open())
		{
			while (!userfileread.eof())
			{
				UserDetail usermodel;

				//read till the end of the file
				userfileread >> usermodel._mName;

				if (usermodel._mName != "")
				{
					userfileread >> usermodel._mEmail;
					userfileread >> usermodel._mDOB;
					userfileread >> usermodel._mCNIC;
					userfileread >> usermodel._mRegNumber;
					userfileread >> usermodel._mPassword;
					userfileread >> usermodel._mType;
					userfileread >> usermodel._mStatus;

					userLinkList.AddUser(usermodel);
				}
			}

			userfileread.close();
		}

		//Display the title
		cout << "\n\t**************************"
			<< "\n\t*** Create new Account ***"
			<< "\n\t**************************\n" << endl;

		cout << "\tEnter user type (T for Teacher, S for Student) :";
		cin >> usr_type;

		if (usr_type == "T" || usr_type == "t")
		{
			usr_type = "Teacher";
		}
		else if (usr_type == "S" || usr_type == "s")
		{
			usr_type = "Student";
		}
		
		else
		{
			cout << "\tInvalid input:\n";
			system("pause");
			clearScreen();
			
			createAccount();
		}
		UserDetail newUserModel;

		cin.ignore();
		//prompt for the user basic information
		cout << "\tEnter Full name :";
		getline(cin, newUserModel._mName);

		cout << "\tEnter Email:";
		cin >> newUserModel._mEmail;

		cout << "\tEnter CNIC:";
		cin >> newUserModel._mCNIC;


		//loop to check if the username is unique
		do
		{
			cout << "\tEnter Reg Number:";
			cin >> newUserModel._mRegNumber;

		} while (userLinkList.IsUserExist(newUserModel._mRegNumber));

		cout << "\tEnter password :";
		cin >> newUserModel._mPassword;

		//loop to check the age below 67 if user type is teacher
		if (usr_type == "Teacher")
		{
			do
			{
				cout << "\tEnter dob (dd/mm/yyyy):";
				cin >> newUserModel._mDOB;

				//convert string to number
				num_dob = 2015;//getAge(newUserModel._mDOB);

				if (2019 - num_dob < 67)
				{
					ageValid = true;
					break;
				}
				else
				{
					cout << "\n\tYou are over aged..." << endl << "\t";
					ageValid = false;
					system("pause");
					return;
				}

			} while (!ageValid);
			newUserModel._mType = "Teacher";
		}
		else
		{
			cout << "\tEnter dob (dd/mm/yyyy):";
			cin >> newUserModel._mDOB;
			newUserModel._mType = "Student";
		}

		newUserModel._mStatus = "Pending";

		cout << "\n\tAre you sure to proceed with creating account (Y/N):";
		cin >> confirmation;

		//check if user want to create account
		if (confirmation == 'y' || confirmation == 'Y')
		{
			//Reading previous data to the link list
			userLinkList.AddUser(newUserModel);
			//saving user information into the file name Users.txts

			//ofstream class object
			ofstream userfile("Users.txt");

			//check if file is opened successfully
			if (userfile.is_open())
			{
				//Write previous data to the file
				User *userNode;

				for (userNode = userLinkList.getFirstUser(); userNode != NULL; userNode = userNode->getUserNode())
				{
					userfile << userNode->getName() << endl;
					userfile << userNode->getEmail() << endl;
					userfile << userNode->getDOB() << endl;
					userfile << userNode->getCNIC() << endl;
					userfile << userNode->getRegNum() << endl;
					userfile << userNode->getPassword() << endl;
					userfile << userNode->getType() << endl;
					userfile << userNode->getStatus() << endl;
				}

				//closing file
				userfile.close();

				//Calling genVerificationCode()
				verification_code = genVerificationCode();

				sendCodeByEmail(verification_code);
			}
			//else display error message
			else
				cout << "\n\tUnable to open file";
		}
	}

	//receive usertype and username
	//display Main Menu according to the user type
	void gotoMainMenu(string usertype, string username)
	{
		//check for the user type
		if (usertype == "Admin")
		{
			displayMainAdminMenu(username);
		}
		else if (usertype == "Teacher")
		{
			displayTeacherMenu(username);
		}
		else if (usertype == "Student")
		{
			displayStudentMenu(username);
		}
	}

	void ReadAllUsers()
	{
		teacherLinkList.setFirstUser(NULL);
		studentLinkList.setFirstUser(NULL);
		allUserLinkList.setFirstUser(NULL);

		//Read all user details from file to Link list
		//ifstream class object
		ifstream userfileread("Users.txt");

		//check if file opens
		if (userfileread.is_open())
		{
			while (!userfileread.eof())
			{
				UserDetail usermodel;

				//read till the end of the file
				userfileread >> usermodel._mName;

				if (usermodel._mName != "")
				{
					userfileread >> usermodel._mEmail;
					userfileread >> usermodel._mDOB;
					userfileread >> usermodel._mCNIC;
					userfileread >> usermodel._mRegNumber;
					userfileread >> usermodel._mPassword;
					userfileread >> usermodel._mType;
					userfileread >> usermodel._mStatus;

					if (usermodel._mType == "Teacher")
					{
						teacherLinkList.AddUser(usermodel);
					}
					else if (usermodel._mType == "Student")
					{
						studentLinkList.AddUser(usermodel);
					}
					allUserLinkList.AddUser(usermodel);
				}
			}

			userfileread.close();
		}
	}

	void ReadAllPendingUsers()
	{
		teacherLinkList.setFirstUser(NULL);
		studentLinkList.setFirstUser(NULL);
		allUserLinkList.setFirstUser(NULL);

		//Read all user details from file to Link list
		//ifstream class object
		ifstream userfileread("Users.txt");

		//check if file opens
		if (userfileread.is_open())
		{
			while (!userfileread.eof())
			{
				UserDetail usermodel;

				//read till the end of the file
				userfileread >> usermodel._mName;

				if (usermodel._mName != "")
				{
					userfileread >> usermodel._mEmail;
					userfileread >> usermodel._mDOB;
					userfileread >> usermodel._mCNIC;
					userfileread >> usermodel._mRegNumber;
					userfileread >> usermodel._mPassword;
					userfileread >> usermodel._mType;
					userfileread >> usermodel._mStatus;

					if (usermodel._mStatus == "Pending")
					{
						if (usermodel._mType == "Teacher")
						{
							teacherLinkList.AddUser(usermodel);
						}
						else if (usermodel._mType == "Student")
						{
							studentLinkList.AddUser(usermodel);
						}
					}
					allUserLinkList.AddUser(usermodel);
				}
			}

			userfileread.close();
		}
	}

	void ReadAllCourse()
	{
		courseLinkList.setFirstCourse(NULL);

		//Read all user details from file to Link list
		//ifstream class object
		ifstream userfileread("Courses.txt");

		//check if file opens
		if (userfileread.is_open())
		{
			while (!userfileread.eof())
			{
				CourseDetail usermodel;

				//read till the end of the file
				userfileread >> usermodel._mCourseCode;

				if (usermodel._mCourseCode != "")
				{
					userfileread >> usermodel._mName;
					userfileread >> usermodel._mCreditHr;
					userfileread >> usermodel._preReq;

					courseLinkList.AddCourse(usermodel);
				}
			}

			userfileread.close();
		}
	}

	void AddCourse()
	{
		CourseDetail newCourseModel;

		//prompt for the user basic information
		cout << "\t\t\t\t\tEnter Course Code:";
		cin >> newCourseModel._mCourseCode;

		cout << "\t\t\t\t\tEnter Course Name:";
		cin >> newCourseModel._mName;

		cout << "\t\t\t\t\tEnter Credit Hrs:";
		cin >> newCourseModel._mCreditHr;

		cout << "\t\t\t\t\tEnter pre-Requisities:";
		cin >> newCourseModel._preReq;


		courseLinkList.AddCourse(newCourseModel);

		writeToCourseFile();
		ReadAllCourse();
	}

	void writeToCourseFile()
	{
		//ofstream class object
		ofstream coursefile("Courses.txt");

		//check if file is opened successfully
		if (coursefile.is_open())
		{
			//Write previous data to the file
			Course *courseNode;

			for (courseNode = courseLinkList.getFirstCourse(); courseNode != NULL; courseNode = courseNode->getCourseNode())
			{
				coursefile << courseNode->getCourseCode() << endl;
				coursefile << courseNode->getCourseName() << endl;
				coursefile << courseNode->getCreditHrs() << endl;
				coursefile << courseNode->getPreReq() << endl;
			}

			//closing file
			coursefile.close();
		}
		//else display error message
		else
			cout << "\n\tUnable to open file";
	}

	void writeToUserFile()
	{
		//ofstream class object
		ofstream userfile("Users.txt");

		//check if file is opened successfully
		if (userfile.is_open())
		{
			//Write previous data to the file
			User *userNode;

			for (userNode = allUserLinkList.getFirstUser(); userNode != NULL; userNode = userNode->getUserNode())
			{
				userfile << userNode->getName() << endl;
				userfile << userNode->getEmail() << endl;
				userfile << userNode->getDOB() << endl;
				userfile << userNode->getCNIC() << endl;
				userfile << userNode->getRegNum() << endl;
				userfile << userNode->getPassword() << endl;
				userfile << userNode->getType() << endl;
				userfile << userNode->getStatus() << endl;
			}

			//closing file
			userfile.close();

		}
		//else display error message
		else
			cout << "\n\tUnable to open file";
	}

	void DisplaySpecificCourseFromPointer(Course *course)
	{
		cout << "\t***** Course Details *****" << endl;
		cout << "\tCode : " << course->getCourseCode() << endl
			<< "\tName : " << course->getCourseName() << endl
			<< "\tCredit Hrs : " << course->getCreditHrs() << endl
			<< "\tPre-Requisities : " << course->getPreReq() << endl;
	}

	void DisplaySpecificCourseFromModel(CourseDetail course)
	{
		cout << "\t***** Course Details *****" << endl;
		cout << "\tCode : " << course._mCourseCode << endl
			<< "\tName : " << course._mName << endl
			<< "\tCredit Hrs : " << course._mCreditHr << endl
			<< "\tPre-Requisities : " << course._preReq << endl;
	}

	void UpdateCourse()
	{
		CourseDetail newCourseModel;

		//prompt for the user basic information
		cout << "\t\t\t\t\tEnter Course Code You want to Update :";
		cin >> newCourseModel._mCourseCode;

		ReadAllCourse();

		Course *searchedCourse = courseLinkList.getSpecificCourse(newCourseModel._mCourseCode);

		DisplaySpecificCourseFromPointer(searchedCourse);

		cout << "\t\t\t\t\tPlease enter updated data to Update Selected Course:\n";
		//prompt for the user basic information

		cout << "\t\t\t\t\tEnter Course Code:";
		cin >> newCourseModel._mCourseCode;

		cout << "\t\t\t\t\tEnter Course Name:";
		cin >> newCourseModel._mName;

		cout << "\t\t\t\t\tEnter Credit Hrs:";
		cin >> newCourseModel._mCreditHr;

		cout << "\t\t\t\t\tEnter pre-Requisities:";
		cin >> newCourseModel._preReq;
		cout << endl << endl;


		//update data to the searched Course
		searchedCourse->setCourseCode(newCourseModel._mCourseCode);
		searchedCourse->setCourseName(newCourseModel._mName);
		searchedCourse->setCreditHrs(newCourseModel._mCreditHr);
		searchedCourse->setPreReq(newCourseModel._preReq);

		writeToCourseFile();
		ReadAllCourse();
	}

	void DeleteCourse()
	{
		CourseDetail newCourseModel;

		//prompt for the user basic information
		cout << "\t\t\t\t\tEnter Course Code You want to Delete :";
		cin >> newCourseModel._mCourseCode;

		ReadAllCourse();

		CourseDetail searchedCourse = courseLinkList.DeleteCourse(newCourseModel);

		DisplaySpecificCourseFromModel(searchedCourse);

		writeToCourseFile();
		ReadAllCourse();

		system("pause");

	}

	void ViewAllCourses()
	{
		ReadAllCourse();
		clearScreen();
		cout << "\t\t\t****** Following are the list of courses ******" << endl;
		cout << "\n\t" << setw(10) << "Course Code" << setw(50) << "Title" << setw(10) << "Credit Hr" << setw(10) << "Pre-Req" << endl;

		for (Course *p = courseLinkList.getFirstCourse(); p != NULL; p = p->getCourseNode())
		{
			cout << "\n\t" << setw(10) << p->getCourseCode() << setw(50) << p->getCourseName() << setw(10) << p->getCreditHrs() << setw(10) << p->getPreReq();
		}
		cout << "\n\t";
		system("pause");
	}

	void ViewAssignedTeacherToCourse()
	{
		cin.ignore();
		string coursecode;
		cout<<"\n\tEnter Course Code to get the list of All Teachers Assigned to Course : ";
		getline(cin,coursecode);

		readAllAssignedCourseData();

		cout<<"\n\t\tFollowing are the list of Teachers who are assigned to Course with Course code :"<<coursecode<<endl;

		cout << "\n\t" << setw(10) << "Course Code" << setw(10) << "Title" << setw(10) << "Reg #" << setw(20) << "Name"  << setw(30) << "Email" << setw(10) << "DOB" << endl;

		if(!assignedTeacherList.IsUserListEmpty())
		{
			for(User *p = assignedTeacherList.getFirstUser();p!=NULL;p=p->getUserNode())
			{

				for(Course *c = p->getCourseLinkList().getFirstCourse();c!=NULL;c=c->getCourseNode())
				{
					if(c->getCourseCode()==coursecode)
					{
						cout << "\n\t" << setw(10) << c->getCourseCode() << setw(10) << c->getCourseName() << setw(10) << p->getRegNum() << setw(20) << p->getName()  << setw(30) << p->getEmail() << setw(10) << p->getDOB() ;
					}
					cout<<endl;
				}
			}
		}
		system("pause");
	}

	void ViewAssignedTeacherToCourseByStudent(string username)
	{
		readAllEnrolledCourseData();
		readAllAssignedCourseData();

		cout<<"\n\tFollowing are the list of Teacher who are assigned to Course Enrolled by Student :"<<username<<endl;

		cout << "\n\t" << setw(10) << "Course Code" << setw(10) << "Title" << setw(10) << "Reg #" << setw(20) << "Name"  << setw(30) << "Email" << setw(10) << "DOB" << endl;

		if(!enrolledStudentList.IsUserListEmpty())
		{
			for(User *ap = enrolledStudentList.getFirstUser();ap!=NULL;ap=ap->getUserNode())
			{
				if(ap->getRegNum()==stoi(username))
				{
					for(Course *ac = ap->getCourseLinkList().getFirstCourse();ac!=NULL;ac=ac->getCourseNode())
					{
						string coursecode = ac->getCourseCode();

						if(!assignedTeacherList.IsUserListEmpty())
						{
							for(User *p = assignedTeacherList.getFirstUser();p!=NULL;p=p->getUserNode())
							{
								for(Course *c = p->getCourseLinkList().getFirstCourse();c!=NULL;c=c->getCourseNode())
								{
									if(c->getCourseCode()==coursecode)
									{
											cout << "\t" << setw(10) << c->getCourseCode() << setw(10) << c->getCourseName() << setw(10) << p->getRegNum() << setw(20) << p->getName()  << setw(30) << p->getEmail() << setw(10) << p->getDOB() ;
									}
									cout<<endl;
								}
							}
						}
					}
					break;
				}
			}
		}
		system("pause");
	}

	void ViewEnrolledStudentInCourseByTeacher(string username)
	{
		readAllEnrolledCourseData();
		readAllAssignedCourseData();

		cout<<"\n\tFollowing are the list of Students who are enrolled in Course Assigned to Teacher :"<<username<<endl;

		cout << "\n\t" << setw(10) << "Course Code" << setw(10) << "Title" << setw(10) << "Reg #" << setw(20) << "Name"  << setw(30) << "Email" << setw(10) << "DOB" << endl;

		if(!assignedTeacherList.IsUserListEmpty())
		{
			for(User *ap = assignedTeacherList.getFirstUser();ap!=NULL;ap=ap->getUserNode())
			{
				if(ap->getRegNum()==stoi(username))
				{
					for(Course *ac = ap->getCourseLinkList().getFirstCourse();ac!=NULL;ac=ac->getCourseNode())
					{
						string coursecode = ac->getCourseCode();

						if(!enrolledStudentList.IsUserListEmpty())
						{
							for(User *p = enrolledStudentList.getFirstUser();p!=NULL;p=p->getUserNode())
							{
								for(Course *c = p->getCourseLinkList().getFirstCourse();c!=NULL;c=c->getCourseNode())
								{
									if(c->getCourseCode()==coursecode)
									{
											cout << "\n\t" << setw(10) << c->getCourseCode() << setw(10) << c->getCourseName() << setw(10) << p->getRegNum() << setw(20) << p->getName()  << setw(30) << p->getEmail() << setw(10) << p->getDOB() ;
									}
								}
							}
						}
					}
					break;
				}
			}
		}
		cout<<endl;
		system("pause");
	}
	
	void ViewEnrolledStudentInCourse()
	{
		cin.ignore();
		string coursecode;
		cout<<"\n\tEnter Course Code to get the list of All Students enrolled in Course : ";
		getline(cin,coursecode);

		readAllEnrolledCourseData();

		cout<<"\n\tFollowing are the list of Students who are enrolled in Course with Course code :"<<coursecode<<endl;

		cout << "\n\t" << setw(10) << "Course Code" << setw(10) << "Title" << setw(10) << "Reg #" << setw(20) << "Name"  << setw(30) << "Email" << setw(10) << "DOB" << endl;

		if(!enrolledStudentList.IsUserListEmpty())
		{
			for(User *p = enrolledStudentList.getFirstUser();p!=NULL;p=p->getUserNode())
			{

				for(Course *c = p->getCourseLinkList().getFirstCourse();c!=NULL;c=c->getCourseNode())
				{
					if(c->getCourseCode()==coursecode)
					{
							cout << "\t" << setw(10) << c->getCourseCode() << setw(10) << c->getCourseName() << setw(10) << p->getRegNum() << setw(20) << p->getName()  << setw(30) << p->getEmail() << setw(10) << p->getDOB() ;
					}
					cout<<endl;
				}
			}
		}
		system("pause");
	}

	void DisplayCourseMenu()
	{
		int user_choice;

		do
		{
			//Calling clearScreen()
			clearScreen();

			//display menu
			cout << "\n\t\t\t\t\t*************************"
				<< "\n\t\t\t\t\t*** Course Main Menu ***"
				<< "\n\t\t\t\t\t*************************";

			cout << "\n\n\t\t\t\t\t1. Add Course" << endl
				<< "\t\t\t\t\t2. Update Course" << endl
				<< "\t\t\t\t\t3. Delete Course" << endl
				<< "\t\t\t\t\t4. View All Course" << endl
				<< "\t\t\t\t\t5. View Assigned Teacher for a Course" << endl
				<< "\t\t\t\t\t6. View Enrolled Student in a Courses" << endl
				<< "\t\t\t\t\t7. Go Back" << endl;

			cout << "\n\t\t\t\t\tEnter your choice : ";
			user_choice=isvalidLoopInput(7);

			switch (user_choice)
			{
			case 1:
				AddCourse();
				break;

			case 2:
				UpdateCourse();
				break;

			case 3:
				DeleteCourse();
				break;


			case 4:
				ViewAllCourses();
				break;

			case 5:
				ViewAssignedTeacherToCourse();
				break;

			case 6:
				ViewEnrolledStudentInCourse();
				break;

			case 7:
				return;
				break;

			default:
				cout << "\n\t\t\t\t\tInvalid choice please try again...";
			}

		} while (user_choice != 7);
	}

	void CourseAssignRequest()
	{
		//required array list
		string regno, coursecode;
		int status_response;

		readAllAssignedCourseData();

		clearScreen();

		cout << "\n\t\t\t\t\t****************************************************"
			<< "\n\t\t\t\t\t********** Course Enrollment Request List **********"
			<< "\n\t\t\t\t\t****************************************************" << endl;


		//printing the header for table
		cout << "\n\t" << setw(5) << "Teacher RegNo " << setw(20) << "Teacher Username" << setw(20) << "Course Code" << setw(25) << "Course Name" << setw(25) << "Request Status" << endl;

		if (assignedTeacherList.getFirstUser() != NULL)
		{
			for (User *s = assignedTeacherList.getFirstUser(); s != NULL; s = s->getUserNode())
			{

				for (Course *c = s->getCourseLinkList().getFirstCourse(); c != NULL; c = c->getCourseNode())
				{
					if (c->getStatus() != "Approved")
					{
						cout << "\n\t" << setw(5) << s->getRegNum() << setw(25) << s->getName() << setw(20) << c->getCourseCode() << setw(30) << c->getCourseName() << setw(20) << c->getStatus();
					}
				}
			}

			//printing the end of the table
			cout << "\n\t========================================================================================" << endl;

			//prompt for the request number 
			cout << "\n\tPlease select the regno to select the Teacher :";
			cin >> regno;

			//prompt for the request number 
			cout << "\n\tPlease select the course code to select the Course:";
			cin >> coursecode;

			//prompt for the status 
			cout << "\tSelect status to respond to the request (1 for Approve, 2 for Reject) :";
			cin >> status_response;

			User *searchUser = assignedTeacherList.searchSpecificUserByPointer(stoi(regno));

			//update the status
			switch (status_response)
			{
			case 1:
				searchUser->getCourseLinkList().getSpecificCourse(coursecode)->setStatus("Approved");
				break;
			case 2:
				searchUser->getCourseLinkList().getSpecificCourse(coursecode)->setStatus("Rejected");
				break;
			}

			WriteAllAssignedData();
		}
		else
			cout << "\n\tNo More Enrollment Request..." << endl;

		system("pause");

	}

	void DisplayStudentList()
	{

		//Calling clearScreen()
		clearScreen();

		cout << "\n\t\t\t\t\t******************************************"
			<< "\n\t\t\t\t\t************* ALL Student List ***********"
			<< "\n\t\t\t\t\t******************************************" << endl;

		//check if student list is empty
		if (studentLinkList.getFirstUser() != NULL)
		{
			//printing the header for table
			cout << "\n\t" << setw(5) << "Reg No" << setw(20) << "Name" << setw(30) << "Email" << setw(10) << "DOB" << setw(10) << "Password" << setw(20) << "Request Status" << endl;

			//printing all the student request with status pending to the screen
			for (User *p = studentLinkList.getFirstUser(); p != NULL; p = p->getUserNode())
			{
				cout << "\n\t" << setw(5) << p->getRegNum() << setw(20) << p->getName() << setw(30) << p->getEmail() << setw(10) << p->getDOB() << setw(10) << p->getPassword() << setw(20) << p->getStatus() << endl;
			}

			//printing the end of the table
			cout << "\n\t========================================================================================" << endl;
		}
		else
			cout << "\n\tNo More Registeration Request..." << endl;
		system("pause");
	}

	void DisplayTeacherList()
	{

		//Calling clearScreen()
		clearScreen();

		cout << "\n\t\t\t\t\t******************************************"
			<< "\n\t\t\t\t\t************* ALL Teacher List ***********"
			<< "\n\t\t\t\t\t******************************************" << endl;

		//check if student list is empty
		if (teacherLinkList.getFirstUser() != NULL)
		{
			//printing the header for table
			cout << "\n\t" << setw(5) << "Reg No" << setw(20) << "Name" << setw(20) << "Email" << setw(15) << "DOB" << setw(15) << "Password" << setw(20) << "Request Status" << endl;

			//printing all the student request with status pending to the screen
			for (User *p = teacherLinkList.getFirstUser(); p != NULL; p = p->getUserNode())
			{
				cout << "\n\t" << setw(5) << p->getRegNum() << setw(20) << p->getName() << setw(20) << p->getEmail() << setw(20) << p->getDOB() << setw(10) << p->getPassword() << setw(20) << p->getStatus() << endl;
			}

			//printing the end of the table
			cout << "\n\t========================================================================================" << endl;
		}
		else
			cout << "\n\tNo More Registeration Request..." << endl;
		system("pause");
	}

	void StudentRegisterRequest()
	{
		int regno;
		int status_response;

		//Calling clearScreen()
		clearScreen();

		cout << "\n\t\t\t\t\t******************************************"
			<< "\n\t\t\t\t\t********** Student Request List **********"
			<< "\n\t\t\t\t\t******************************************" << endl;

		ReadAllPendingUsers();

		//check if student list is empty
		if (studentLinkList.getFirstUser() != NULL)
		{
			//printing the header for table
			cout << "\n\t" << setw(5) << "Reg No" << setw(20) << "Name" << setw(30) << "Email" << setw(10) << "DOB" << setw(10) << "Password" << setw(20) << "Request Status" << endl;

			//printing all the student request with status pending to the screen
			for (User *p = studentLinkList.getFirstUser(); p != NULL; p = p->getUserNode())
			{
				cout << "\n\t" << setw(5) << p->getRegNum() << setw(20) << p->getName() << setw(30) << p->getEmail() << setw(10) << p->getDOB() << setw(10) << p->getPassword() << setw(20) << p->getStatus() << endl;
			}

			//printing the end of the table
			cout << "\n\t========================================================================================" << endl;

			//prompt for the request number 
			cout << "\n\t\t\t\t\tPlease select student Reg # to approve/reject the request :";
			cin >> regno;

			//prompt for the status 
			cout << "\tSelect status to respond to the request (1 for Approve, 2 for Reject) :";
			cin >> status_response;

			User *searchUser = allUserLinkList.searchSpecificUserByPointer(regno);

			//update the status
			switch (status_response)
			{
			case 1:
				searchUser->setStatus("Approved");
				break;
			case 2:
				searchUser->setStatus("Reject");
				break;
			}

			writeToUserFile();
			ReadAllPendingUsers();
		}
		else
			cout << "\n\t\t\t\t\tNo More Registeration Request..." << endl;
		system("pause");

	}

	void TeacherRegisterRequest()
	{
		int regno;
		int status_response;

		//Calling clearScreen()
		clearScreen();

		cout << "\n\t\t\t\t\t******************************************"
			<< "\n\t\t\t\t\t********** Teacher Request List **********"
			<< "\n\t\t\t\t\t******************************************" << endl;

		ReadAllPendingUsers();

		//check if teacher list is empty
		if (teacherLinkList.getFirstUser() != NULL)
		{
			//printing the header for table
			cout << "\n\t" << setw(5) << "Reg No" << setw(20) << "Name" << setw(20) << "Email" << setw(15) << "DOB" << setw(15) << "Password" << setw(20) << "Request Status" << endl;

			//printing all the student request with status pending to the screen
			for (User *p = teacherLinkList.getFirstUser(); p != NULL; p = p->getUserNode())
			{
				cout << "\n\t" << setw(5) << p->getRegNum() << setw(20) << p->getName() << setw(20) << p->getEmail() << setw(20) << p->getDOB() << setw(10) << p->getPassword() << setw(20) << p->getStatus() << endl;
			}

			//printing the end of the table
			cout << "\n\t========================================================================================" << endl;

			//prompt for the request number 
			cout << "\n\tPlease select teacher Reg # to approve/reject the request :";
			cin >> regno;

			//prompt for the status 
			cout << "\tSelect status to respond to the request (1 for Approve, 2 for Reject) :";
			cin >> status_response;

			User *searchUser = allUserLinkList.searchSpecificUserByPointer(regno);

			//update the status
			switch (status_response)
			{
			case 1:
				searchUser->setStatus("Approved");
				break;
			case 2:
				searchUser->setStatus("Reject");
				break;
			}

			writeToUserFile();
			ReadAllPendingUsers();
		}
		else
			cout << "\n\t\t\t\t\tNo More Registeration Request..." << endl;
		system("pause");

	}

	void CourseEnrolRequest()
	{
		//required array list
		string regno, coursecode;
		int status_response;

		readAllEnrolledCourseData();

		clearScreen();

		cout << "\n\t\t\t\t\t****************************************************"
			<< "\n\t\t\t\t\t********** Course Enrollment Request List **********"
			<< "\n\t\t\t\t\t****************************************************" << endl;


		//printing the header for table
		cout << "\n\t" << setw(5) << "Student RegNo " << setw(20) << "Student Username" << setw(15) << "Course Code" << setw(25) << "Course Name" << setw(20) << "Request Status" << endl;

		if (enrolledStudentList.getFirstUser() != NULL)
		{
			for (User *s = enrolledStudentList.getFirstUser(); s != NULL; s = s->getUserNode())
			{

				for (Course *c = s->getCourseLinkList().getFirstCourse(); c != NULL; c = c->getCourseNode())
				{
					if (c->getStatus() != "Approved")
					{
						cout << "\n\t" << setw(5) << s->getRegNum() << setw(20) << s->getName() << setw(20) << c->getCourseCode() << setw(35) << c->getCourseName() << setw(15) << c->getStatus();
					}
				}
			}

			//printing the end of the table
			cout << "\n\t========================================================================================" << endl;

			//prompt for the request number 
			cout << "\n\t\t\t\t\tPlease select the regno to select the student :";
			cin >> regno;

			//prompt for the request number 
			cout << "\n\t\t\t\t\tPlease select the course code to select the Course:";
			cin >> coursecode;

			//prompt for the status 
			cout << "\tSelect status to respond to the request (1 for Approve, 2 for Reject) :";
			cin >> status_response;

			User *searchUser = enrolledStudentList.searchSpecificUserByPointer(stoi(regno));

			//update the status
			switch (status_response)
			{
			case 1:
				searchUser->getCourseLinkList().getSpecificCourse(coursecode)->setStatus("Approved");
				break;
			case 2:
				searchUser->getCourseLinkList().getSpecificCourse(coursecode)->setStatus("Rejected");
				break;
			}

			WriteAllEnrolledData();
		}
		else
			cout << "\n\tNo More Enrollment Request..." << endl;

		system("pause");
	}

	void WriteAllEnrolledData()
	{

		//writing data back with new course
		//ofstream class object
		ofstream courseEnrolFile("StudentEnrolledCourses.txt");

		//check if file is ready to open successfully
		if (courseEnrolFile.is_open())
		{
			//Write previous data to the file
			User *userNode;

			for (userNode = enrolledStudentList.getFirstUser(); userNode != NULL; userNode = userNode->getUserNode())
			{
				courseEnrolFile << userNode->getRegNum() << endl;

				for (Course *coursenodet = userNode->getCourseLinkList().getFirstCourse(); coursenodet != NULL; coursenodet = coursenodet->getCourseNode())
				{
					courseEnrolFile << coursenodet->getCourseCode() << endl;
					courseEnrolFile << coursenodet->getStatus() << endl;
				}

				courseEnrolFile << "***\n";
			}
		}
		else
		{
			cout << "\n\tFile not found...!" << endl;
			system("pause");
			return;
		}

	}
	void WriteAllAssignedData()
	{

		//writing data back with new course
		//ofstream class object
		ofstream courseEnrolFile("TeacherSelectedCourses.txt");

		//check if file is ready to open successfully
		if (courseEnrolFile.is_open())
		{
			//Write previous data to the file
			User *userNode;

			for (userNode = assignedTeacherList.getFirstUser(); userNode != NULL; userNode = userNode->getUserNode())
			{
				courseEnrolFile << userNode->getRegNum() << endl;

				for (Course *coursenodet = userNode->getCourseLinkList().getFirstCourse(); coursenodet != NULL; coursenodet = coursenodet->getCourseNode())
				{
					courseEnrolFile << coursenodet->getCourseCode() << endl;
					courseEnrolFile << coursenodet->getStatus() << endl;
				}

				courseEnrolFile << "***\n";
			}
		}
		else
		{
			cout << "\n\tFile not found...!" << endl;
			system("pause");
			return;
		}

	}


	void DisplayAdminStudentMenu()
	{
		int user_choice;

		do
		{
			//Calling clearScreen()
			clearScreen();

			//display menu
			cout << "\n\t\t\t\t\t*************************"
				<< "\n\t\t\t\t\t*** Admin Student Menu ***"
				<< "\n\t\t\t\t\t*************************";

			cout << "\n\n\t\t\t\t\t1. Registeration Request" << endl
				<< "\t\t\t\t\t2. Enrollment Request" << endl
				<< "\t\t\t\t\t3. All Student List" << endl
				<< "\t\t\t\t\t4. Back" << endl;

			cout << "\n\t\t\t\t\tEnter your choice : ";
			cin >> user_choice;

			switch (user_choice)
			{
			case 1:
				StudentRegisterRequest();
				break;

			case 2:
				CourseEnrolRequest();
				break;

			case 3:
				ReadAllUsers();
				DisplayStudentList();
				break;

			case 4:
				return;
				break;

			default:
				cout << "\n\t\t\t\t\tInvalid choice please try again...";
			}

		} while (user_choice != 4);
	}

	void DisplayAdminTeacherMenu()
	{
		int user_choice;

		do
		{
			//Calling clearScreen()
			clearScreen();

			//display menu
			cout << "\n\t\t\t\t\t*************************"
				<< "\n\t\t\t\t\t*** Admin Teacher Menu ***"
				<< "\n\t\t\t\t\t*************************";

			cout << "\n\n\t\t\t\t\t1. Registeration Request" << endl
				<< "\t\t\t\t\t2. Assignment Request" << endl
				<< "\t\t\t\t\t3. All Teacher List" << endl
				<< "\t\t\t\t\t4. Back" << endl;

			cout << "\n\t\t\t\t\tEnter your choice : ";
			user_choice=isvalidLoopInput(4);

			switch (user_choice)
			{
			case 1:
				TeacherRegisterRequest();
				break;

			case 2:
				CourseAssignRequest();
				break;

			case 3:
				ReadAllUsers();
				DisplayTeacherList();
				break;

			case 4:
				return;
				break;

			default:
				cout << "\n\t\t\t\t\tInvalid choice please try again...";
			}

		} while (user_choice != 4);
	}

	//display Admin Menu
	void displayMainAdminMenu(string username)
	{
		int user_choice;

		do
		{
			//Calling clearScreen()
			clearScreen();

			//display menu
			cout << "\n\t\t\t\t\t*************************"
				<< "\n\t\t\t\t\t*** Admin Main Menu ***"
				<< "\n\t\t\t\t\t*************************";

			cout << "\n\t\t\t\t\t1. Teacher" << endl
				<< "\t\t\t\t\t2. Student" << endl
				<< "\t\t\t\t\t3. Course" << endl
				<< "\t\t\t\t\t4. sign out" << endl;

			cout << "\n\t\t\t\t\tEnter your choice : ";
			user_choice = isvalidLoopInput(4);

			switch (user_choice)
			{
			case 1:
				ReadAllUsers();
				DisplayAdminTeacherMenu();
				break;

			case 2:
				ReadAllUsers();
				DisplayAdminStudentMenu();
				break;

			case 3:
				ReadAllCourse();
				DisplayCourseMenu();
				break;

			case 4:
				return;
				break;

			default:
				cout << "\n\t\t\t\t\tInvalid choice please try again...";
			}

		} while (user_choice != 4);
	}

	// Display the verification screen
	//Prompt the user to enter the verification code
	//if code is valid then proceed further
	//otherwise prompt again 
	//after 3 attempt go back to login screen
	bool displayVerificationScreen()
	{
		//required variable to hold the verification code entered by user
		int verification_code, temp_code;
		int attempt = 0;
		bool isverified = false;

		//ifstream class object
		ifstream emailFile("Email.txt");

		//check if file open successfully
		if (emailFile.is_open())
		{
			//read code from the file
			emailFile >> temp_code;

			//closing the file
			emailFile.close();
		}
		else
			cout << "\n\t\t\t\t\tUnable to open the file!";

		while (attempt < 3)
		{

			//prompt user to enter the verification code
			cout << "\n\t\t\t\t\tEnter your's verification code :";
			cin >> verification_code;

			//check if user entered verification code is valid
			if (verification_code == temp_code)
			{
				isverified = true;
				break;
			}
			else
			{
				cout << "\n\t" << 3 - attempt << " attempts left of 3" << endl;
				attempt++;
			}
		}

		//check the attempts are over or isverified
		if (isverified)
		{
			return true;
		}
		else
			return false;
	}

	void readAllCoursesForStudent(User *loggedInUser)
	{
		string temp_sname;
		string temp_ccode;
		string temp_cstatus;
		int numOfCourse = 0;

		ReadAllCourse();

		//ifstream class object
		ifstream studentSelectedCourseFile("StudentEnrolledCourses.txt");

		//check if file is ready to open successfully
		if (studentSelectedCourseFile.is_open())
		{
			while (!studentSelectedCourseFile.eof())
			{
				//reading student name from file
				//search for the logged in teacher
				getline(studentSelectedCourseFile, temp_sname);

				if (temp_sname != "")
				{
					do{
						getline(studentSelectedCourseFile, temp_ccode);

						if (temp_ccode != "***")
						{
							getline(studentSelectedCourseFile, temp_cstatus);

							if (loggedInUser->getRegNum() == stoi(temp_sname))
							{
								Course *tc = courseLinkList.getSpecificCourse(temp_ccode);
								tc->setStatus(temp_cstatus);

								loggedInUser->AddCourse(tc);
							}
						}
						else
							break;
					} while (temp_ccode != "***");
				}
				else
				{
					do{
						getline(studentSelectedCourseFile, temp_ccode);
					} while (temp_ccode != "***");
				}
			}
		}

		studentSelectedCourseFile.close();

	}

	void readAllCoursesForTeacher(User *loggedInUser)
	{
		string temp_sname;
		string temp_ccode;
		string temp_cstatus;
		int numOfCourse = 0;

		ReadAllCourse();

		//ifstream class object
		ifstream teacherSelectedCourseFile("TeacherSelectedCourses.txt");

		//check if file is ready to open successfully
		if (teacherSelectedCourseFile.is_open())
		{
			while (!teacherSelectedCourseFile.eof())
			{
				//reading student name from file
				//search for the logged in teacher
				getline(teacherSelectedCourseFile, temp_sname);

				if (temp_sname != "")
				{
					do{
						getline(teacherSelectedCourseFile, temp_ccode);

						if (temp_ccode != "***")
						{
							getline(teacherSelectedCourseFile, temp_cstatus);

							if (loggedInUser->getRegNum() == stoi(temp_sname))
							{
								Course *tc = courseLinkList.getSpecificCourse(temp_ccode);
								tc->setStatus(temp_cstatus);

								loggedInUser->AddCourse(tc);
							}
						}
						else
							break;
					} while (temp_ccode != "***");
				}
				else
				{
					do{
						getline(teacherSelectedCourseFile, temp_ccode);
					} while (temp_ccode != "***");
				}
			}
		}

		teacherSelectedCourseFile.close();

	}

	void readAllEnrolledCourseData()
	{
		string temp_sname;
		string temp_ccode;
		string temp_cstatus;
		int numOfCourse = 0;

		ReadAllCourse();
		ReadAllUsers();

		enrolledStudentList.setFirstUser(NULL);

		//ifstream class object
		ifstream studentSelectedCourseFile("StudentEnrolledCourses.txt");

		//check if file is ready to open successfully
		if (studentSelectedCourseFile.is_open())
		{
			while (!studentSelectedCourseFile.eof())
			{
				//reading student name from file
				//search for the logged in teacher
				getline(studentSelectedCourseFile, temp_sname);

				if (temp_sname != "")
				{
					User *tu = studentLinkList.searchSpecificUserByPointer(stoi(temp_sname));

					enrolledStudentList.AddUser(tu->getUserDetail());

					do{
						getline(studentSelectedCourseFile, temp_ccode);

						if (temp_ccode != "***")
						{
							getline(studentSelectedCourseFile, temp_cstatus);

							Course *tc = courseLinkList.getSpecificCourse(temp_ccode);
							tc->setStatus(temp_cstatus);

							enrolledStudentList.searchSpecificUserByPointer(stoi(temp_sname))->AddCourse(tc);
						}
						else
							break;
					} while (temp_ccode != "***");
				}
				else
				{
					do{
						getline(studentSelectedCourseFile, temp_ccode);
					} while (temp_ccode != "***");
				}
			}
		}

		studentSelectedCourseFile.close();

	}

	void readAllAssignedCourseData()
	{
		string temp_sname;
		string temp_ccode;
		string temp_cstatus;
		int numOfCourse = 0;

		ReadAllCourse();
		ReadAllUsers();

		assignedTeacherList.setFirstUser(NULL);

		//ifstream class object
		ifstream teacherSelectedCourseFile("TeacherSelectedCourses.txt");

		//check if file is ready to open successfully
		if (teacherSelectedCourseFile.is_open())
		{
			while (!teacherSelectedCourseFile.eof())
			{
				//reading student name from file
				//search for the logged in teacher
				getline(teacherSelectedCourseFile, temp_sname);

				if (temp_sname != "")
				{
					User *tu = teacherLinkList.searchSpecificUserByPointer(stoi(temp_sname));

					assignedTeacherList.AddUser(tu->getUserDetail());

					do{
						getline(teacherSelectedCourseFile, temp_ccode);

						if (temp_ccode != "***")
						{
							getline(teacherSelectedCourseFile, temp_cstatus);

							Course *tc = courseLinkList.getSpecificCourse(temp_ccode);
							tc->setStatus(temp_cstatus);

							assignedTeacherList.searchSpecificUserByPointer(stoi(temp_sname))->AddCourse(tc);
						}
						else
							break;
					} while (temp_ccode != "***");
				}
				else
				{
					do{
						getline(teacherSelectedCourseFile, temp_ccode);
					} while (temp_ccode != "***");
				}
			}
		}

		teacherSelectedCourseFile.close();

	}

	//check if the maximum course is enrolled by the student
	//if maximum course enrollment reach to 5 then return true
	//otherwise return false
	bool isMaxEnrolCourseReached(User *loggedInUser)
	{
		//required variables
		int numOfCourse = 0;

		numOfCourse = loggedInUser->getCourseLinkList().getNoOfCourses();
		if (numOfCourse == 5)
		{
			return true;
		}
		else
			return false;
	}

	//check if the maximum course is enrolled by the student
	//if maximum course enrollment reach to 5 then return true
	//otherwise return false
	bool isMaxSelCourseReached(User *loggedInUser)
	{
		//required variables
		int numOfCourse = 0;

		numOfCourse = loggedInUser->getCourseLinkList().getNoOfCourses();
		if (numOfCourse == 3)
		{
			return true;
		}
		else
			return false;
	}

	//check if the course is already enrolled by the student
	//if course is enrolled then return true
	//otherwise return false
	bool isCourseAlreadyEnrolled(string c_code, User *loggedInUser)
	{
		//required variables
		bool isAlreadySelected = false;
		string temp_sname, temp_ccode, temp_cstatus;

		Course *tc = loggedInUser->getCourseLinkList().getSpecificCourse(c_code);

		if (tc != NULL)
		{
			isAlreadySelected = true;
		}

		return isAlreadySelected;
	}

	bool isCoursePreReqAlreadyEnrolled(string c_code, User *loggedInUser)
	{
		//required variables
		bool isAlreadySelected = false;
		string temp_sname, temp_ccode, temp_cstatus, temp_prereq;

		//Course *tc=loggedInUser->getCourseLinkList().getSpecificCourse(c_code);

		Course *tc = courseLinkList.getSpecificCourse(c_code);

		if (tc != NULL)
		{
			temp_prereq = tc->getPreReq();

			if (temp_prereq != "-1")
			{
				tc = loggedInUser->getCourseLinkList().getSpecificCourse(temp_prereq);

				if (tc != NULL)
				{
					isAlreadySelected = true;
				}
			}
			else
			{
				isAlreadySelected = true;
			}
		}
		else
		{
			isAlreadySelected = true;
		}
		return isAlreadySelected;
	}

	//receive student unique id and course code
	//apply for the course to be enrolled with the status as pending
	void applyCourseEnrollment(User *loggedInUser)
	{
		readAllEnrolledCourseData();
		bool useralreadyexists = false;

		//writing data back with new course
		//ofstream class object
		ofstream courseEnrolFile("StudentEnrolledCourses.txt");

		//check if file is ready to open successfully
		if (courseEnrolFile.is_open())
		{
			//Write previous data to the file
			User *userNode;

			for (userNode = enrolledStudentList.getFirstUser(); userNode != NULL; userNode = userNode->getUserNode())
			{
				if (userNode->getRegNum() == loggedInUser->getRegNum())
				{
					useralreadyexists = true;

					userNode->setCourseLinkList(loggedInUser->getCourseLinkList());

				}
			}

			if (!useralreadyexists)
			{
				enrolledStudentList.AddUser(loggedInUser->getUserDetail());
				enrolledStudentList.searchSpecificUserByPointer(loggedInUser->getRegNum())->setCourseLinkList(loggedInUser->getCourseLinkList());
			}

			for (userNode = enrolledStudentList.getFirstUser(); userNode != NULL; userNode = userNode->getUserNode())
			{
				courseEnrolFile << userNode->getRegNum() << endl;
				Course *wtc;

				for (wtc = userNode->getCourseLinkList().getFirstCourse(); wtc != NULL; wtc = wtc->getCourseNode())
				{
					courseEnrolFile << wtc->getCourseCode() << endl;
					courseEnrolFile << wtc->getStatus() << endl;
				}
				courseEnrolFile << "***" << endl;
			}
			courseEnrolFile.close();
		}
		else
		{
			cout << "\n\tFile not found...!" << endl;
			system("pause");
			return;
		}

	}

	void applyCourseSelection(User *loggedInUser)
	{
		readAllAssignedCourseData();
		bool useralreadyexists = false;

		//writing data back with new course
		//ofstream class object
		ofstream courseEnrolFile("TeacherSelectedCourses.txt");

		//check if file is ready to open successfully
		if (courseEnrolFile.is_open())
		{
			//Write previous data to the file
			User *userNode;

			for (userNode = assignedTeacherList.getFirstUser(); userNode != NULL; userNode = userNode->getUserNode())
			{
				if (userNode->getRegNum() == loggedInUser->getRegNum())
				{
					useralreadyexists = true;

					userNode->setCourseLinkList(loggedInUser->getCourseLinkList());

				}
			}

			if (!useralreadyexists)
			{
				assignedTeacherList.AddUser(loggedInUser->getUserDetail());
				assignedTeacherList.searchSpecificUserByPointer(loggedInUser->getRegNum())->setCourseLinkList(loggedInUser->getCourseLinkList());
			}

			for (userNode = assignedTeacherList.getFirstUser(); userNode != NULL; userNode = userNode->getUserNode())
			{
				courseEnrolFile << userNode->getRegNum() << endl;
				Course *wtc;

				for (wtc = userNode->getCourseLinkList().getFirstCourse(); wtc != NULL; wtc = wtc->getCourseNode())
				{
					courseEnrolFile << wtc->getCourseCode() << endl;
					courseEnrolFile << wtc->getStatus() << endl;
				}
				courseEnrolFile << "***" << endl;
			}
			courseEnrolFile.close();
		}
		else
		{
			cout << "\n\tFile not found...!" << endl;
			system("pause");
			return;
		}

	}

	//CourseEnrolRequest method will display all the requests with the student 
	//username and course code and request status
	void EnrollRequests(string username)
	{
		bool validCourse = false;
		string courseSel;

		//ClearScreen
		clearScreen();

		cout << "\n\t******************************"
			<< "\n\t*** Select Course To Enrol ***"
			<< "\n\t******************************\n";

		ReadAllUsers();

		UserDetail loggedInUserDetail = studentLinkList.searchSpecificUserByModel(stoi(username));

		User *loggedInUser = new User();

		loggedInUser->setCNIC(loggedInUserDetail._mCNIC);
		loggedInUser->setDOB(loggedInUserDetail._mDOB);
		loggedInUser->setEmail(loggedInUserDetail._mEmail);
		loggedInUser->setName(loggedInUserDetail._mName);
		loggedInUser->setPassword(loggedInUserDetail._mPassword);
		loggedInUser->setRegNum(loggedInUserDetail._mRegNumber);
		loggedInUser->setStatus(loggedInUserDetail._mStatus);
		loggedInUser->setType(loggedInUserDetail._mType);
		loggedInUser->getCourseLinkList().setFirstCourse(NULL);
		loggedInUser->setUserNode(NULL);


		readAllCoursesForStudent(loggedInUser);

		//check maximum selected course
		if (!isMaxEnrolCourseReached(loggedInUser))
		{
			ViewAllCourses();

			if (courseLinkList.getNoOfCourses() <= 0)
			{
				cout << "\n\tNo courses to select...!";
				system("pause");
				return;
			}
			else
			{
				if (!isMaxEnrolCourseReached(loggedInUser))
				{
					do
					{
						cout << "\n\tSelect from above list using the CourseCode. as a selection :";
						cin >> courseSel;

						validCourse = isCourseAlreadyEnrolled(courseSel, loggedInUser);

						if (validCourse)
						{
							cout << "\n\tCourse already selected please try other course ...!\n";
							system("pause");
							return;
						}

						validCourse = isCoursePreReqAlreadyEnrolled(courseSel, loggedInUser);

						if (!validCourse)
						{
							cout << "\n\tCourse PRE - REQ course should be enrolled first. Please try another course...!\n";
							system("pause");
							return;
						}
						else
						{
							Course *c = new Course();

							c->setCourseCode(courseLinkList.getSpecificCourse(courseSel)->getCourseCode());
							c->setCourseName(courseLinkList.getSpecificCourse(courseSel)->getCourseName());
							c->setCreditHrs(courseLinkList.getSpecificCourse(courseSel)->getCreditHrs());
							c->setPreReq(courseLinkList.getSpecificCourse(courseSel)->getPreReq());
							c->setCourseNode(NULL);
							c->setStatus("Pending");

							//applying for the course selection process
							loggedInUser->AddCourse(c);//getCourseLinkList().AddCourse(c->getCourseDetail());

							//saving to the file

							applyCourseEnrollment(loggedInUser);
							break;
						}
					} while (validCourse);

				}
				else
				{
					cout << "\n\tOoops! you reached maximum limit of the Course Selection...";
					cout << endl;
					system("pause");
					return;
				}
			}
		}
		else
		{
			cout << "\n\tYou already have reached maximum course selection i.e 5.\n";
			system("pause");
			return;
		}
	}

	//CourseEnrolRequest method will display all the requests with the student 
	//username and course code and request status
	void selectCourse(string username)
	{
		bool validCourse = false;
		string courseSel;

		//ClearScreen
		clearScreen();

		cout << "\n\t\t\t\t\t******************************"
			<< "\n\t\t\t\t\t*** Select Course To Teach ***"
			<< "\n\t\t\t\t\t******************************\n";

		ReadAllUsers();

		UserDetail loggedInUserDetail = teacherLinkList.searchSpecificUserByModel(stoi(username));

		User *loggedInUser = new User();

		loggedInUser->setCNIC(loggedInUserDetail._mCNIC);
		loggedInUser->setDOB(loggedInUserDetail._mDOB);
		loggedInUser->setEmail(loggedInUserDetail._mEmail);
		loggedInUser->setName(loggedInUserDetail._mName);
		loggedInUser->setPassword(loggedInUserDetail._mPassword);
		loggedInUser->setRegNum(loggedInUserDetail._mRegNumber);
		loggedInUser->setStatus(loggedInUserDetail._mStatus);
		loggedInUser->setType(loggedInUserDetail._mType);
		loggedInUser->getCourseLinkList().setFirstCourse(NULL);
		loggedInUser->setUserNode(NULL);


		readAllCoursesForTeacher(loggedInUser);

		//check maximum selected course
		if (!isMaxSelCourseReached(loggedInUser))
		{
			ViewAllCourses();

			if (courseLinkList.getNoOfCourses() <= 0)
			{
				cout << "\n\t\t\t\t\tNo courses to select...!";
				system("pause");
				return;
			}
			else
			{
				if (!isMaxSelCourseReached(loggedInUser))
				{
					do
					{
						cout << "\n\t\t\t\t\tSelect from above list using the CourseCode. as a selection :";
						cin >> courseSel;

						validCourse = isCourseAlreadyEnrolled(courseSel, loggedInUser);

						if (validCourse)
						{
							cout << "\n\t\t\t\t\tCourse already selected please try other course ...!\n";
							system("pause");
							return;
						}
						else
						{

							Course *c = new Course();

							c->setCourseCode(courseLinkList.getSpecificCourse(courseSel)->getCourseCode());
							c->setCourseName(courseLinkList.getSpecificCourse(courseSel)->getCourseName());
							c->setCreditHrs(courseLinkList.getSpecificCourse(courseSel)->getCreditHrs());
							c->setPreReq(courseLinkList.getSpecificCourse(courseSel)->getPreReq());
							c->setCourseNode(NULL);
							c->setStatus("Pending");

							//applying for the course selection process
							loggedInUser->AddCourse(c);//getCourseLinkList().AddCourse(c->getCourseDetail());

							//saving to the file

							applyCourseSelection(loggedInUser);
							break;
						}

					} while (validCourse);

				}
				else
				{
					cout << "\n\tOoops! you reached maximum limit of the Course Selection...";
					cout << endl;
					system("pause");
					return;
				}
			}
		}
		else
		{
			cout << "\n\tYou already have reached maximum course selection i.e 5.\n";
			system("pause");
			return;
		}
	}
	
	void ViewEnrolledCoursesByStudent(string username)
	{
		
		ReadAllCourse();
		readAllEnrolledCourseData();
		

		//Calling clearScreen()
		clearScreen();

		cout << "\n\t\t\t\t\t****************************************"
			<< "\n\t\t\t\t\t************* Student Details ***********"
			<< "\n\t\t\t\t\t*****************************************"<< endl;

		//check if student list is empty
		if (enrolledStudentList.getFirstUser() != NULL)
		{
			//printing the header for table
			cout << "\n\t" << setw(5) << "Reg No" << setw(20) << "Name" << setw(30) << "Email" << setw(10) << "DOB" << setw(10) << "Password" << setw(20) << "Request Status" << endl;

			//printing all the student request with status pending to the screen
			for (User *p = enrolledStudentList.getFirstUser(); p != NULL; p = p->getUserNode())
			{
				if (p->getRegNum() == stoi(username))
				{
					cout << "\n\t" << setw(5) << p->getRegNum() << setw(20) << p->getName() << setw(30) << p->getEmail() << setw(10) << p->getDOB() << setw(10) << p->getPassword() << setw(20) << p->getStatus() << endl;
				
					cout << "\n\t****** Following are the list of courses enrolled by above student ******" << endl;

					cout << "\n\t" << setw(10) << "Course Code" << setw(50) << "Title" << setw(10) << "Credit Hr" << setw(10) << "Pre-Req" << setw(10) << "Status" << endl;

					for (Course *p1 = p->getCourseLinkList().getFirstCourse(); p1 != NULL; p1 = p1->getCourseNode())
					{
						cout << "\n\t" << setw(10) << p1->getCourseCode() << setw(50) << p1->getCourseName() << setw(10) << p1->getCreditHrs() << setw(10) << p1->getPreReq() << setw(10) << p1->getStatus();
					}
					cout << "\n\t";
					system("pause");
					break;
				}

			}

			//printing the end of the table
			cout << "\n\t========================================================================================" << endl;
		}
		else
			cout << "\n\tNo More Registeration Request..." << endl;
		system("pause");
	}

	void ViewSelectedCoursesByTeacher(string username)
	{

		ReadAllCourse();
		readAllAssignedCourseData();


		//Calling clearScreen()
		clearScreen();

		cout << "\n\t\t\t\t\t****************************************"
			<< "\n\t\t\t\t\t************* Teacher Details ***********"
			<< "\n\t\t\t\t\t*****************************************" << endl;

		//check if student list is empty
		if (assignedTeacherList.getFirstUser() != NULL)
		{
			//printing the header for table
			cout << "\n\t" << setw(5) << "Reg No" << setw(20) << "Name" << setw(30) << "Email" << setw(10) << "DOB" << setw(10) << "Password" << setw(20) << "Request Status" << endl;

			//printing all the student request with status pending to the screen
			for (User *p = assignedTeacherList.getFirstUser(); p != NULL; p = p->getUserNode())
			{
				if (p->getRegNum() == stoi(username))
				{
					cout << "\n\t" << setw(5) << p->getRegNum() << setw(20) << p->getName() << setw(30) << p->getEmail() << setw(10) << p->getDOB() << setw(10) << p->getPassword() << setw(20) << p->getStatus() << endl;

					cout << "\n\t****** Following are the list of courses teached by above teacher ******" << endl;

					cout << "\n\t" << setw(10) << "Course Code" << setw(50) << "Title" << setw(10) << "Credit Hr" << setw(10) << "Pre-Req" << setw(10) << "Status" << endl;

					for (Course *p1 = p->getCourseLinkList().getFirstCourse(); p1 != NULL; p1 = p1->getCourseNode())
					{
						cout << "\n\t" << setw(10) << p1->getCourseCode() << setw(50) << p1->getCourseName() << setw(10) << p1->getCreditHrs() << setw(10) << p1->getPreReq() << setw(10) << p1->getStatus();
					}
					cout << "\n\t";
					system("pause");
					break;
				}

			}

			//printing the end of the table
			cout << "\n\t========================================================================================" << endl;
		}
		else
			cout << "\n\tNo More Registeration Request..." << endl;
		system("pause");
	}

	//display Teacher Menu
	void displayTeacherMenu(string username)
	{
		int user_choice;

		do
		{
			//Calling clearScreen()
			clearScreen();

			//display menu
			cout << "\n\t\t\t\t\t*************************"
				<< "\n\t\t\t\t\t*** Teacher Main Menu ***"
				<< "\n\t\t\t\t\t*************************";

			cout << "\n\n\t\t\t\t\t. Select Course" << endl
				<< "\t\t\t\t\t2. View Selected Course" << endl
				<< "\t\t\t\t\t3. View Enrolled Student in a Courses" << endl
				<< "\n\t\t\t\t\t4. sign out" << endl;

			cout << "\n\t\t\t\t\tEnter your choice : ";
			 user_choice=isvalidLoopInput(4);

			switch (user_choice)
			{
			case 1:
				selectCourse(username);
				break;

			case 2:
				ViewSelectedCoursesByTeacher(username);
				break;

			case 3:
				ViewEnrolledStudentInCourseByTeacher(username);
				break;

			case 4:
				return;
				break;

			default:
				cout << "\n\t\t\t\t\tInvalid choice please try again...";
			}

		} while (user_choice != 4);
	}

	//display Student Menu
	void displayStudentMenu(string username)
	{
		int user_choice;

		do
		{
			//Calling clearScreen()
			clearScreen();

			//display menu
			cout << "\n\t\t\t\t\t*************************"
				<< "\n\t\t\t\t\t*** Student Main Menu ***"
				<< "\n\t\t\t\t\t*************************";

			cout << "\n\n\t\t\t\t\t1. Enroll course" << endl
				<< "\t\t\t\t\t2. View Enrolled Courses" << endl
				<< "\t\t\t\t\t3. View Assigned Teacher by Course" << endl
				<< "\t\t\t\t\t4. sign out" << endl;

			cout << "\n\t\t\t\t\tEnter your choice : ";
			user_choice=isvalidLoopInput(4);

			switch (user_choice)
			{
			case 1:
				EnrollRequests(username);
				break;

			case 2:
				ViewEnrolledCoursesByStudent(username);
				break;

			case 3:
				ViewAssignedTeacherToCourseByStudent(username);
				break;

			case 4:
				return;
				break;

			default:
				cout << "\n\t\t\t\t\tInvalid choice please try again...";
			}

		} while (user_choice != 4);
	}
	string takePassword()
	{
		char ch;
		string str;
		ch = _getch();
		while (ch != 13)
		{
			cout << "*";
			str.push_back(ch);
			ch = _getch();
		}
		cout << endl;
		return str;
	}
	//prompt user for username and password
	//check if username and password exists
	//and valid then login else display message
	void signIn()
	{
		//required variable to hold the username and password
		string username, password;
		string temp_username, temp_password, temp_usertype;
		string temp;
		bool isvalid = false;

		//Calling clearScreen()

		do
		{
			clearScreen();

			//Display the title
			cout << "\n\t\t\t\t\t***************************"
				<< "\n\t\t\t\t\t*** Enter Login Details ***"
				<< "\n\t\t\t\t\t***************************\n" << endl;

			//ifsstream class object
			ifstream userFile("Users.txt");

			//prompt for the username
			cout << "\n\t\t\t\t\tEnter your Unique ID :";
			cin >> username;

			//prompt for the password
			cout << "\n\t\t\t\t\tEnter your password :";
			password=takePassword();
			

			//check if file is opened properly
			if (userFile.is_open())
			{
				//iterate through every record
				while (!userFile.eof())
				{
					//reading fullname and ignore
					getline(userFile, temp);
					//reading email and ignore
					getline(userFile, temp);
					//reading dob and ignore
					getline(userFile, temp);
					//reading cnic and ignore
					getline(userFile, temp);
					//reading regno and ignore
					getline(userFile, temp_username);
					//reading password
					getline(userFile, temp_password);
					//reading type
					getline(userFile, temp_usertype);
					//reading status and ignore
					getline(userFile, temp);

					//check if the username and password are valid
					if (username == temp_username && password == temp_password && temp == "Approved")
					{
						isvalid = true;
						break;
					}
				}

				if (!isvalid)
				{
					cout << "\n\t\t\t\t\tInvalid username or password. Please try again...\n\t";
					system("pause");
				}
			}
			else
				cout << "\n\tUnable to open file!";

			//closing file
			userFile.close();
		} while (!isvalid);


		//Calling displayVerificationScreen()
		isvalid = displayVerificationScreen();

		//check if verification code is valid
		if (isvalid)
		{
			//Calling gotoMainMenu()
			gotoMainMenu(temp_usertype, username);
		}
		else
		{
			clearScreen();
			signIn();
		}
	}

};

#endif