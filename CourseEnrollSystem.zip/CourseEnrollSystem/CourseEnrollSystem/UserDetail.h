#ifndef USERDETAIL_H
#define USERDETAIL_H

#include <iostream>
#include <string>

using namespace std;

struct UserDetail
{
	int _mRegNumber;
	string _mName;
	string _mEmail;
	string _mPassword;
	string _mDOB;
	string _mCNIC;
	string _mStatus;
	string _mType;
};

#endif