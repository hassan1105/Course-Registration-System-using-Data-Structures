// CourseEnrollSystem.cpp : Defines the entry point for the console application.
//

#define _CRT_SECURE_NO_WARNINGS


#include "stdafx.h"
#include "myInterface.h"

using namespace std;

int main()
{
	//required variables
	int login_choice;
	myInterface gui;

	// Use current time as  
	// seed for random generator 
	srand(time(0));

	//iterate until user wish to exist the program
	do
	{
		//Calling login menu screen
		login_choice = gui.loginMenuScreen();

		switch (login_choice)
		{
			//case 1 is login 
		case 1:
			//Calling signIn()
			gui.signIn();
			break;

			//case 2 is create account
		case 2:
			//Calling createAccount()
			gui.createAccount();
			break;

			//case 3 is terminate program
		case 3:
			//Calling displayGoodByeMessage
			gui.displayGoodByeMessage();
			break;

		}

	} while (login_choice != 3);

	cout << "\t";
	system("pause");

	return 0;
}

