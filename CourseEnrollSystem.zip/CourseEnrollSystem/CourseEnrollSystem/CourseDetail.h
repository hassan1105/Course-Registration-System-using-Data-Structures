#ifndef COURSEDETAIL_H
#define COURSEDETAIL_H

#include <iostream>
#include <string>

using namespace std;

struct CourseDetail
{
	string _mCourseCode;
	string _mName;
	string _preReq;
	string _mStatus;
	int _mCreditHr;
};

#endif