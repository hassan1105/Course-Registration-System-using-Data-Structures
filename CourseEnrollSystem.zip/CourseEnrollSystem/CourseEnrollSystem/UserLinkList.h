#ifndef USERLINKLIST_H
#define USERLINKLIST_H
#include "User.h"
class UserLinkList
{
private:
	User *FirstUser, *LastUser;
	int noOfUser;
public:
	UserLinkList();
	User* CreatUser();
	void NewUser(UserDetail model);
	void AddUser(UserDetail model);

	void UpdateUser(UserDetail model);
	
	UserDetail DeleteUser(UserDetail model);
	UserDetail DeleteLastUser(UserDetail model);
	UserDetail DeleteFirstUser(UserDetail model);
	
	bool IsUserListEmpty();
	int getNoOfUser();
	bool IsUserExist(int UserRegNo);

	void AddCourse(int UserRegNo, CourseDetail cmodel);
	//void AddTeacher(int UserRegNo, string CourseCode, UserDetail detail);
	//CourseDetail DeleteCourse(int UserRegNo, string CourseCode);
	User* getFirstUser();
	User* getNextUser(User *user);

	void setFirstUser(User *t);
	
	User* searchSpecificUserByPointer(int regno);
	UserDetail searchSpecificUserByModel(int regno);

};

User* UserLinkList::searchSpecificUserByPointer(int regno)
{
	if (FirstUser != NULL)
	{
		User *p;

		for (p = FirstUser; p != NULL; p = p->getUserNode())
		{
			if (p->getRegNum() == regno)
			{
				return p;
			}
		}

		return NULL;
	}
}

UserDetail UserLinkList::searchSpecificUserByModel(int regno)
{
	if (FirstUser == NULL)
		cout << "Underflow";
	else
	{
		User *p;
		for (p = FirstUser; p != NULL; p = p->getUserNode())
		{
			if (p->getRegNum() == regno)
			{
				UserDetail temp;
				temp._mCNIC = p->getCNIC();
				temp._mDOB = p->getDOB();
				temp._mEmail = p->getEmail();
				temp._mName = p->getName();
				temp._mPassword = p->getPassword();
				temp._mRegNumber = p->getRegNum();
				temp._mStatus = p->getStatus();
				temp._mType = p->getType();

				return temp;
			}
		}
	}
}

void UserLinkList::setFirstUser(User *t)
{
	FirstUser = t;
}

User* UserLinkList::getFirstUser()
{
	return FirstUser;
}

User* UserLinkList::getNextUser(User *user)
{
	return user->getUserNode();
}

UserLinkList::UserLinkList()
{
	FirstUser = NULL;
	LastUser = NULL;
	noOfUser = 0;
}
User* UserLinkList::CreatUser()
{
	User *p;
	p = new User();
	return p;
}
void UserLinkList::NewUser(UserDetail model)
{
	User *q = CreatUser();
	q->setCNIC(model._mCNIC);
	q->setDOB(model._mDOB);
	q->setEmail(model._mEmail);
	q->setName(model._mName);
	q->setPassword(model._mPassword);
	q->setRegNum(model._mRegNumber);
	q->setStatus(model._mStatus);
	q->setType(model._mType);
	q->setUserNode(NULL);
	FirstUser = q;
	LastUser = q;
	noOfUser = noOfUser++;
}
void UserLinkList::AddUser(UserDetail model)
{
	if (FirstUser == NULL)
		NewUser(model);
	else
	{
		User *q = NULL, *p;
		for (p = FirstUser; p->getUserNode() != NULL; p = p->getUserNode())
		{
		}

		q = CreatUser();
		q->setCNIC(model._mCNIC);
		q->setDOB(model._mDOB);
		q->setEmail(model._mEmail);
		q->setName(model._mName);
		q->setPassword(model._mPassword);
		q->setRegNum(model._mRegNumber);
		q->setStatus(model._mStatus);
		q->setType(model._mType);
		q->setUserNode(NULL);
		p->setUserNode(q);

		LastUser = q;
		noOfUser = noOfUser++;
	}
}
void UserLinkList::UpdateUser(UserDetail model)
{
	if (FirstUser != NULL)
	{
		User *p;
		for (p = FirstUser; p->getUserNode() != NULL && p->getRegNum() != model._mRegNumber; p = p->getUserNode());
		p->setCNIC(model._mCNIC);
		p->setDOB(model._mDOB);
		p->setEmail(model._mEmail);
		p->setName(model._mName);
		p->setPassword(model._mPassword);
		p->setStatus(model._mStatus);

	}

}

UserDetail UserLinkList::DeleteUser(UserDetail model)
{
	if (FirstUser == NULL)
		cout << "underflow";
	if (FirstUser->getUserNode() == NULL)
		return(DeleteFirstUser(model));
	else
	{
		User *q = NULL, *p;
		for (p = FirstUser; p->getUserNode() != NULL && p->getRegNum() != model._mRegNumber; p = p->getUserNode())
			q = p;
		if (p == NULL)
			cout << "Not Found";
		if (p->getUserNode() == NULL)
			return DeleteLastUser(model);
		else
		{
			User *r = p->getUserNode();
			q->setUserNode(r);//here i change the syntax from q->setUserNode(p->getUserNode()) to this
			UserDetail temp;
			temp._mCNIC = p->getCNIC();
			temp._mDOB = p->getDOB();
			temp._mEmail = p->getEmail();
			temp._mName = p->getName();
			temp._mPassword = p->getPassword();
			temp._mRegNumber = p->getRegNum();
			temp._mStatus = p->getStatus();
			delete p;
			noOfUser = noOfUser--;
			return temp;
		}
	}
}
UserDetail UserLinkList::DeleteLastUser(UserDetail model)
{
	if (FirstUser == NULL)
		cout << "underflow";
	if (FirstUser->getUserNode() == NULL)
		return(DeleteFirstUser(model));
	else
	{
		User *q = NULL, *p;
		for (p = FirstUser; p->getUserNode() != NULL && p->getRegNum() != model._mRegNumber; p = p->getUserNode())
			q = p;
		q->setUserNode(NULL);
		LastUser = q;
		UserDetail temp;
		temp._mCNIC = p->getCNIC();
		temp._mDOB = p->getDOB();
		temp._mEmail = p->getEmail();
		temp._mName = p->getName();
		temp._mPassword = p->getPassword();
		temp._mRegNumber = p->getRegNum();
		temp._mStatus = p->getStatus();
		delete p;
		noOfUser = noOfUser--;
		return temp;

	}
}
UserDetail UserLinkList::DeleteFirstUser(UserDetail model)
{
	if (FirstUser == NULL)
	{
		cout << "Underflow";
	}
	else
	{
		User *p;
		p = FirstUser;
		FirstUser = FirstUser->getUserNode();
		LastUser = FirstUser->getUserNode();
		noOfUser = noOfUser--;
		UserDetail temp;
		temp._mCNIC = p->getCNIC();
		temp._mDOB = p->getDOB();
		temp._mEmail = p->getEmail();
		temp._mName = p->getName();
		temp._mPassword = p->getPassword();
		temp._mRegNumber = p->getRegNum();
		temp._mStatus = p->getStatus();
		delete p;
		noOfUser = noOfUser--;
		return temp;
	}
}
bool UserLinkList::IsUserListEmpty()
{
	return FirstUser == NULL;
}
int UserLinkList::getNoOfUser()
{
	return noOfUser;
}
bool UserLinkList::IsUserExist(int UserRegNo)
{
	if (FirstUser == NULL)
		return false;
	else
	{
		User *p, *q;
		bool isFound = false;
		UserDetail temp;
		for (p = FirstUser; p != NULL; p = p->getUserNode())
		{
			if (p->getRegNum() == UserRegNo)
			{
				temp._mCNIC = p->getCNIC();
				temp._mDOB = p->getDOB();
				temp._mEmail = p->getEmail();
				temp._mName = p->getName();
				temp._mPassword = p->getPassword();
				temp._mRegNumber = p->getRegNum();
				temp._mStatus = p->getStatus();
				temp._mType = p->getType();

				isFound = true;
				break;
			}
		}

		return isFound;

	}
}

void UserLinkList::AddCourse(int UserRegNo, CourseDetail cmodel)
{
	if (FirstUser != NULL)
	{
		User *p;

		for (p = FirstUser; p->getUserNode() != NULL && p->getRegNum() != UserRegNo; p = p->getUserNode());

		Course *c;
		c = new Course();
		c->setCourseCode(cmodel._mCourseCode);
		c->setCourseName(cmodel._mName);
		c->setCreditHrs(cmodel._mCreditHr);
		c->setPreReq(cmodel._mStatus);
		/*
		c->setCourseNode(NULL);

		if (p->getCourseNode() == NULL)
		{
		p->setCourseNode(c);
		}
		else
		{
		Course *q = NULL, *r;

		for (r = p->getCourseNode(); r->getCourseNode() != NULL; r = r->getCourseNode());

		r->setCourseNode(c);

		}*/

	}
}
/*
void UserLinkList::AddTeacher(int UserRegNo, string CourseCode, UserDetail detail)
{
if (FirstUser != NULL)
{
User *p;

for (p = FirstUser; p->getUserNode() != NULL && p->getRegNum() != UserRegNo; p = p->getUserNode());

if (p->getCourseNode() != NULL)
{
Course *c;

for (c = p->getCourseNode(); c->getCourseNode() != NULL && c->getCourseCode() != CourseCode; c = c->getCourseNode());

User *t = new User();

t->setName(detail._mName);
t->setRegNum(detail._mRegNumber);
t->setEmail(detail._mEmail);
t->setDOB(detail._mDOB);
t->setPassword(detail._mPassword);
t->setCNIC(detail._mCNIC);
t->setStatus(detail._mStatus);
t->setUserNode(NULL);

}
}
}
*//*
CourseDetail UserLinkList::DeleteCourse(int UserRegNo, string CourseCode)
{
if (FirstUser != NULL)
{
User *p;

for (p = FirstUser; p->getUserNode() != NULL && p->getRegNum() != UserRegNo; p = p->getUserNode());

Course *c = p->getCourseNode();

if (c != NULL)
{

if (c->getCourseNode() == NULL && c->getCourseCode() == CourseCode)
{
//				User *t = c->getUserNode();

//				delete t;

Course *p = c;

CourseDetail temp;
temp._mCourseCode = p->getCourseCode();
temp._mCreditHr = p->getCreditHrs();
temp._mName = p->getCourseName();

delete p;

p->setCourseNode(NULL);

return temp;
}
else
{
Course *q = NULL, *p;//i change p to p->getcoursenode()
for (p = c; p->getCourseNode() != NULL && p->getCourseCode() != CourseCode; p = p->getCourseNode())
q = p; //P points to the last node and q points to the 2nd last

if (p == NULL)
cout << "Not found";
else if (p->getCourseNode() == NULL)
{
q->setCourseNode(NULL);


CourseDetail temp;
temp._mCourseCode = p->getCourseCode();
temp._mCreditHr = p->getCreditHrs();
temp._mName = p->getCourseName();

delete p;

return temp;
}
else
{
Course  *r = p->getCourseNode();
q->setCourseNode(p->getCourseNode());

CourseDetail temp;
temp._mCourseCode = p->getCourseCode();
temp._mCreditHr = p->getCreditHrs();
temp._mName = p->getCourseName();

delete p;

return temp;
}
}

}
}
}
*/
#endif